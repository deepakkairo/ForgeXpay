import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, User as FirebaseUser } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase.ts';
import { apiRequest } from '../lib/api.ts';

export type RoleCode = 'SUPER_ADMIN' | 'FINANCE_ADMIN' | 'ADMIN_HQ' | 'EMPLOYEE' | 'CLIENT';

export interface ProfileUser {
  id: string;
  uid: string;
  email: string;
  displayName: string;
  photoUrl: string | null;
  roles: RoleCode[];
  mfaEnabled: boolean;
  lastReauthAt: string | null;
}

export interface ActiveReceivingSummary {
  id: string;
  accountCode: string;
  upiId: string;
  displayPayeeName: string;
  manualCheckAttested: boolean;
}

interface AuthContextValue {
  firebaseUser: FirebaseUser | null;
  profile: ProfileUser | null;
  unreadNotifications: number;
  activeReceivingConfigured: boolean;
  activeReceivingSummary: ActiveReceivingSummary | null;
  loading: boolean;
  authError: string | null;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  hasAnyRole: (...roles: RoleCode[]) => boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<ProfileUser | null>(null);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [activeReceivingConfigured, setActiveReceivingConfigured] = useState(false);
  const [activeReceivingSummary, setActiveReceivingSummary] =
    useState<ActiveReceivingSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const loadBackendProfile = useCallback(async () => {
    try {
      const data = await apiRequest<{
        user: ProfileUser;
        unreadNotifications: number;
        activeReceivingConfigured: boolean;
        activeReceivingSummary?: ActiveReceivingSummary | null;
      }>('/me');
      setProfile(data.user);
      setUnreadNotifications(data.unreadNotifications);
      setActiveReceivingConfigured(data.activeReceivingConfigured);
      setActiveReceivingSummary(data.activeReceivingSummary ?? null);
      setAuthError(null);
    } catch (err) {
      console.error('Failed to sync profile:', err);
      setAuthError(err instanceof Error ? err.message : 'Unable to load session profile.');
    }
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        await loadBackendProfile();
      } else {
        setProfile(null);
        setUnreadNotifications(0);
        setActiveReceivingSummary(null);
      }
      setLoading(false);
    });
    return () => unsub();
  }, [loadBackendProfile]);

  const signInWithGoogle = async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleAuthProvider);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In failed.';
      setAuthError(msg);
    }
  };

  const logout = async () => {
    await signOut(auth);
    setProfile(null);
    setActiveReceivingSummary(null);
  };

  const hasAnyRole = useCallback(
    (...allowed: RoleCode[]) => {
      if (!profile) return false;
      return profile.roles.some((r) => allowed.includes(r));
    },
    [profile]
  );

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        unreadNotifications,
        activeReceivingConfigured,
        activeReceivingSummary,
        loading,
        authError,
        signInWithGoogle,
        logout,
        refreshProfile: loadBackendProfile,
        hasAnyRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
