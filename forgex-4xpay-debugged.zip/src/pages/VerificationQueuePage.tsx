import React, { useEffect, useState, useCallback } from 'react';
import { CheckCircle, XCircle, Upload, AlertCircle } from 'lucide-react';
import { apiRequest } from '../lib/api.ts';
import { formatInr, formatUtcDateTime, rupeesInputToPaise } from '../lib/format.ts';
import { EmptyState, Modal, SkeletonRows, StatusText } from '../components/Shell.tsx';

interface QueueItem {
  attempt: {
    id: string;
    paymentRef: string;
    expectedAmountPaise: number;
    reportedAmountPaise: number | null;
    status: string;
    customerReportedUtr: string | null;
    customerReportNote: string | null;
    requiresDualApproval: boolean;
    firstApproverUserId: string | null;
    createdAt: string;
  };
  paymentRequest: { requestRef: string; category: string; title: string };
  customer: { customerRef: string; name: string; email: string };
  project: { projectRef: string; name: string };
  invoice: { invoiceRef: string };
  receivingAccount: {
    accountCode: string;
    bankName: string;
    accountNumberMasked: string;
    upiId: string;
  };
  suggestedBankMatches: Array<{
    match: { id: string; matchClassification: string; confidenceScore: number; matchReasonsJson: string[] };
    bankTx: { id: string; bankReferenceUtr: string | null; amountPaise: number; transactionDate: string };
  }>;
}

interface ReconMatchRow {
  id: string;
  matchClassification: string;
  confidenceScore: number;
  matchReasonsJson: string[];
  reviewNote: string | null;
  bankTransaction: {
    id: string;
    amountPaise: number;
    bankReferenceUtr: string | null;
    transactionDate: string;
    description: string;
    settlementStatus: string;
  };
  receivingAccount: { accountCode: string; bankName: string; upiId: string };
  linkedPayment: {
    id: string;
    paymentRef: string;
    expectedAmountPaise: number;
    status: string;
    customerName: string;
    invoiceRef: string;
  } | null;
}

interface AccountOption {
  id: string;
  accountCode: string;
  bankName: string;
  accountNumberMasked: string;
  upiId: string;
}

export function VerificationQueuePage() {
  const [tab, setTab] = useState<'queue' | 'reconciliation'>('queue');
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [matches, setMatches] = useState<ReconMatchRow[]>([]);
  const [accounts, setAccounts] = useState<AccountOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Manual confirm modal
  const [confirmTarget, setConfirmTarget] = useState<QueueItem | null>(null);
  const [confirmForm, setConfirmForm] = useState({
    verifiedUtr: '',
    creditedRupees: '',
    bankDate: new Date().toISOString().slice(0, 10),
    notes: '',
  });
  const [rejectTarget, setRejectTarget] = useState<QueueItem | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [markAsReview, setMarkAsReview] = useState(false);

  // CSV statement import modal
  const [csvOpen, setCsvOpen] = useState(false);
  const [csvAccountId, setCsvAccountId] = useState('');
  const [csvFilename, setCsvFilename] = useState('bank-statement.csv');
  const [csvContent, setCsvContent] = useState('');
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState({
    dateColumn: 'Date',
    directionColumn: 'Type',
    amountColumn: 'Amount',
    utrColumn: 'UTR',
    descriptionColumn: 'Narration',
  });

  // Manual bind modal for ambiguous/unmatched statement credit
  const [bindMatch, setBindMatch] = useState<ReconMatchRow | null>(null);
  const [bindAttemptId, setBindAttemptId] = useState('');
  const [bindUtrOverride, setBindUtrOverride] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [qRes, rRes, aRes] = await Promise.all([
        apiRequest<{ queue: QueueItem[] }>('/verification-queue'),
        apiRequest<{ matches: ReconMatchRow[] }>('/reconciliation/matches'),
        apiRequest<{ accounts: AccountOption[] }>('/admin/receiving-accounts'),
      ]);
      setQueue(qRes.queue);
      setMatches(rRes.matches);
      setAccounts(aRes.accounts);
      if (aRes.accounts.length > 0 && !csvAccountId) {
        setCsvAccountId(aRes.accounts[0].id);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load verification workspace.');
    } finally {
      setLoading(false);
    }
  }, [csvAccountId]);

  useEffect(() => {
    load();
  }, [load]);

  const openConfirm = (item: QueueItem) => {
    setConfirmTarget(item);
    const rupees = ((item.attempt.reportedAmountPaise || item.attempt.expectedAmountPaise) / 100).toFixed(2);
    setConfirmForm({
      verifiedUtr: item.attempt.customerReportedUtr || item.suggestedBankMatches[0]?.bankTx.bankReferenceUtr || '',
      creditedRupees: rupees,
      bankDate: new Date().toISOString().slice(0, 10),
      notes: '',
    });
    setError(null);
  };

  const handleConfirmManual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmTarget) return;
    setSubmitting(true);
    setError(null);
    try {
      const res = await apiRequest<{
        stage: string;
        paymentRef: string;
        receiptNumber?: string;
        ledgerRef?: string;
      }>(`/verifications/${confirmTarget.attempt.id}/confirm`, {
        method: 'POST',
        body: {
          verifiedUtr: confirmForm.verifiedUtr.trim(),
          creditedAmountPaise: rupeesInputToPaise(confirmForm.creditedRupees),
          bankTransactionDate: confirmForm.bankDate,
          notes: confirmForm.notes.trim(),
        },
      });
      if (res.stage === 'FIRST_APPROVAL_RECORDED') {
        setNotice(
          `First approval recorded for high-value payment ${res.paymentRef}. A second distinct Finance/Super Admin must now confirm.`
        );
      } else {
        setNotice(
          `Payment ${res.paymentRef} VERIFIED. Ledger credit ${res.ledgerRef} and Receipt ${res.receiptNumber} issued atomically.`
        );
      }
      setConfirmTarget(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verification failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleReject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectTarget) return;
    setSubmitting(true);
    setError(null);
    try {
      await apiRequest(`/verifications/${rejectTarget.attempt.id}/reject`, {
        method: 'POST',
        body: { reason: rejectReason.trim(), markAsReview },
      });
      setNotice(
        `${rejectTarget.attempt.paymentRef} moved to ${markAsReview ? 'REVIEW_REQUIRED' : 'FAILED_REPORTED'}.`
      );
      setRejectTarget(null);
      setRejectReason('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Action failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCsvFileUpload = (file: File) => {
    setCsvFilename(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || '');
      setCsvContent(text);
      const firstLine = text.replace(/^\uFEFF/, '').split(/\r?\n/)[0] || '';
      const cols = firstLine.split(',').map((c) => c.trim().replace(/^"|"$/g, '')).filter(Boolean);
      setCsvHeaders(cols);
      if (cols.length >= 3) {
        setMapping({
          dateColumn: cols.find((c) => /date/i.test(c)) || cols[0],
          directionColumn: cols.find((c) => /type|dr|cr|dir/i.test(c)) || cols[1] || '',
          amountColumn: cols.find((c) => /amt|amount|credit/i.test(c)) || cols[2] || '',
          utrColumn: cols.find((c) => /utr|ref|chq/i.test(c)) || cols[3] || cols[0],
          descriptionColumn: cols.find((c) => /desc|narr|partic|rem/i.test(c)) || cols[cols.length - 1],
        });
      }
    };
    reader.readAsText(file);
  };

  const handleImportCsv = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await apiRequest<{
        importBatch: {
          importRef: string;
          creditRows: number;
          matchedCount: number;
          ambiguousCount: number;
          unmatchedCount: number;
          duplicateQuarantinedCount: number;
        };
      }>('/reconciliation/imports', {
        method: 'POST',
        body: {
          receivingAccountId: csvAccountId,
          sourceFilename: csvFilename,
          csvContent,
          columnMapping: mapping,
        },
      });
      const b = res.importBatch;
      setNotice(
        `Imported ${b.importRef}: ${b.creditRows} credits analyzed (${b.matchedCount} matched, ${b.ambiguousCount} ambiguous, ${b.unmatchedCount} unmatched, ${b.duplicateQuarantinedCount} duplicates quarantined).`
      );
      setCsvOpen(false);
      setTab('reconciliation');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'CSV reconciliation import failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmMatch = async (matchRow: ReconMatchRow, attemptOverride?: string, utrOverride?: string) => {
    setSubmitting(true);
    setError(null);
    try {
      const res = await apiRequest<{ verification: { paymentRef: string; receiptNumber?: string } }>(
        `/reconciliation/matches/${matchRow.id}/confirm`,
        {
          method: 'POST',
          body: {
            paymentAttemptId: attemptOverride || matchRow.linkedPayment?.id,
            utrOverride: utrOverride || matchRow.bankTransaction.bankReferenceUtr || '',
            note: 'Confirmed from imported bank statement credit',
          },
        }
      );
      setNotice(
        `Bank credit confirmed for ${res.verification.paymentRef}. Receipt ${res.verification.receiptNumber || '(awaiting 2nd approval)'}.`
      );
      setBindMatch(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Match confirmation failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRejectMatch = async (matchId: string) => {
    setError(null);
    try {
      await apiRequest(`/reconciliation/matches/${matchId}/reject`, {
        method: 'POST',
        body: { note: 'Rejected by Finance Admin during statement review' },
      });
      setNotice('Reconciliation match rejected.');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reject match.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Hybrid Payment Verification & Reconciliation
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Verify incoming funds strictly from your actual banking app or imported CSV bank statements. Zero fabricated real-time bank checks.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setCsvOpen(true)}
          disabled={accounts.length === 0}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950 disabled:opacity-40 whitespace-nowrap"
        >
          <Upload className="w-3.5 h-3.5" />
          <span>Import Bank Statement CSV</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="inline-flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
        <button
          type="button"
          onClick={() => setTab('queue')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            tab === 'queue'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Manual Verification Queue ({queue.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('reconciliation')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            tab === 'reconciliation'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Statement Reconciliation Matches ({matches.length})
        </button>
      </div>

      {notice && (
        <div className="border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/20 rounded-lg px-4 py-3 text-xs text-emerald-800 dark:text-emerald-300">
          {notice}
        </div>
      )}
      {error && (
        <div className="border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/20 rounded-lg px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {loading ? (
        <SkeletonRows rows={5} />
      ) : tab === 'queue' ? (
        queue.length === 0 ? (
          <EmptyState
            title="Verification queue is clear"
            description="Customer-initiated and customer-reported UPI payments awaiting bank-credit verification will appear here."
          />
        ) : (
          <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-950/40">
                    <th className="py-2.5 px-4 font-medium">Payment ID · Invoice</th>
                    <th className="py-2.5 px-4 font-medium">Customer · Account</th>
                    <th className="py-2.5 px-4 font-medium text-right">Expected</th>
                    <th className="py-2.5 px-4 font-medium">Reported UTR · Bank Match</th>
                    <th className="py-2.5 px-4 font-medium">Status</th>
                    <th className="py-2.5 px-4 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {queue.map((item) => (
                    <tr key={item.attempt.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4">
                        <div className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                          {item.attempt.paymentRef}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                          {item.invoice.invoiceRef} · {item.paymentRequest.category}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900 dark:text-slate-100">
                          {item.customer.name}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                          {item.receivingAccount.bankName} ({item.receivingAccount.accountNumberMasked})
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-right">
                        <div className="font-semibold text-slate-900 dark:text-slate-100">
                          {formatInr(item.attempt.expectedAmountPaise)}
                        </div>
                        {item.attempt.requiresDualApproval && (
                          <div className="text-[10px] text-amber-700 dark:text-amber-400">
                            {item.attempt.firstApproverUserId
                              ? '1st Approved · Needs 2nd'
                              : 'Dual Approval Required'}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-mono text-slate-800 dark:text-slate-200">
                          {item.attempt.customerReportedUtr || 'No UTR reported'}
                        </div>
                        {item.suggestedBankMatches.length > 0 && (
                          <div className="text-[11px] text-emerald-700 dark:text-emerald-400">
                            Statement match: {item.suggestedBankMatches[0].match.matchClassification} (
                            {item.suggestedBankMatches[0].bankTx.bankReferenceUtr || 'No UTR'})
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <StatusText status={item.attempt.status} />
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                        <button
                          type="button"
                          onClick={() => openConfirm(item)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded bg-emerald-700 text-white hover:bg-emerald-800"
                        >
                          <CheckCircle className="w-3 h-3" />
                          <span>Confirm Credit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setRejectTarget(item);
                            setRejectReason('');
                            setMarkAsReview(false);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <XCircle className="w-3 h-3" />
                          <span>Reject / Review</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      ) : matches.length === 0 ? (
        <EmptyState
          title="No bank statement credits imported"
          description="Import a CSV bank statement for a specific receiving account. Only CREDIT rows are evaluated, duplicate rows are quarantined, and transactions are never auto-matched solely by amount."
          action={
            accounts.length > 0 ? (
              <button
                type="button"
                onClick={() => setCsvOpen(true)}
                className="px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
              >
                Import CSV Statement
              </button>
            ) : undefined
          }
        />
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-950/40">
                  <th className="py-2.5 px-4 font-medium">Bank Credit · UTR</th>
                  <th className="py-2.5 px-4 font-medium text-right">Amount</th>
                  <th className="py-2.5 px-4 font-medium">Candidate Payment</th>
                  <th className="py-2.5 px-4 font-medium">Classification · Reasoning</th>
                  <th className="py-2.5 px-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {matches.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4">
                      <div className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                        {m.bankTransaction.bankReferenceUtr || 'NO UTR'}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 max-w-xs truncate">
                        {m.bankTransaction.description || '—'}
                      </div>
                      <div className="text-[11px] font-mono text-slate-400">
                        {formatUtcDateTime(m.bankTransaction.transactionDate)} · {m.receivingAccount.bankName}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right font-semibold">
                      {formatInr(m.bankTransaction.amountPaise)}
                    </td>
                    <td className="py-3 px-4">
                      {m.linkedPayment ? (
                        <>
                          <div className="font-mono font-medium text-slate-900 dark:text-slate-100">
                            {m.linkedPayment.paymentRef}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">
                            {m.linkedPayment.customerName} · {m.linkedPayment.invoiceRef}
                          </div>
                        </>
                      ) : (
                        <span className="text-slate-400">Unassigned (manual bind required)</span>
                      )}
                    </td>
                    <td className="py-3 px-4 max-w-sm">
                      <StatusText status={m.matchClassification} />
                      <div className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                        {m.matchReasonsJson.join(' · ')}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                      {m.matchClassification !== 'CONFIRMED' &&
                        m.matchClassification !== 'REJECTED' && (
                          <>
                            {m.linkedPayment ? (
                              <button
                                type="button"
                                disabled={submitting}
                                onClick={() => handleConfirmMatch(m)}
                                className="px-2.5 py-1 text-xs font-medium rounded bg-emerald-700 text-white hover:bg-emerald-800"
                              >
                                Confirm
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => {
                                  setBindMatch(m);
                                  setBindAttemptId(queue[0]?.attempt.id || '');
                                  setBindUtrOverride(m.bankTransaction.bankReferenceUtr || '');
                                }}
                                className="px-2.5 py-1 text-xs font-medium rounded bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
                              >
                                Bind & Verify
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handleRejectMatch(m.id)}
                              className="px-2.5 py-1 text-xs font-medium rounded border border-slate-200 dark:border-slate-700"
                            >
                              Reject
                            </button>
                          </>
                        )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Manual Verification Confirmation Modal */}
      <Modal
        open={Boolean(confirmTarget)}
        onClose={() => setConfirmTarget(null)}
        title={`Confirm Bank Credit — ${confirmTarget?.attempt.paymentRef}`}
        subtitle="Only confirm after verifying the actual credit inside your authorised banking application. Duplicate UTRs are rejected."
      >
        <form onSubmit={handleConfirmManual} className="space-y-4">
          <div className="border border-slate-200 dark:border-slate-800 rounded-md p-3 text-xs space-y-1">
            <div>
              Customer: <span className="font-medium">{confirmTarget?.customer.name}</span> · Invoice:{' '}
              <span className="font-mono">{confirmTarget?.invoice.invoiceRef}</span>
            </div>
            <div>
              Expected Amount:{' '}
              <span className="font-mono font-semibold">
                {formatInr(confirmTarget?.attempt.expectedAmountPaise)}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Bank Reference / UTR</label>
              <input
                type="text"
                required
                value={confirmForm.verifiedUtr}
                onChange={(e) => setConfirmForm({ ...confirmForm, verifiedUtr: e.target.value })}
                placeholder="6–35 alphanumeric chars"
                className="w-full px-3 py-2 text-sm font-mono uppercase rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Credited Amount (INR)</label>
              <input
                type="text"
                required
                value={confirmForm.creditedRupees}
                onChange={(e) => setConfirmForm({ ...confirmForm, creditedRupees: e.target.value })}
                className="w-full px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Bank Transaction Date</label>
            <input
              type="date"
              required
              value={confirmForm.bankDate}
              onChange={(e) => setConfirmForm({ ...confirmForm, bankDate: e.target.value })}
              className="w-full px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Verification Notes</label>
            <textarea
              rows={2}
              value={confirmForm.notes}
              onChange={(e) => setConfirmForm({ ...confirmForm, notes: e.target.value })}
              placeholder="Confirmed in HDFC/ICICI statement"
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setConfirmTarget(null)}
              className="px-4 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-xs font-medium rounded-md bg-emerald-700 text-white hover:bg-emerald-800 disabled:opacity-50"
            >
              {submitting ? 'Verifying...' : 'Confirm & Issue Receipt'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Reject / Flag Review Modal */}
      <Modal
        open={Boolean(rejectTarget)}
        onClose={() => setRejectTarget(null)}
        title={`Reject or Flag — ${rejectTarget?.attempt.paymentRef}`}
      >
        <form onSubmit={handleReject} className="space-y-4">
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={markAsReview}
              onChange={(e) => setMarkAsReview(e.target.checked)}
            />
            <span>Keep in REVIEW_REQUIRED instead of FAILED_REPORTED</span>
          </label>
          <div>
            <label className="block text-xs font-medium mb-1">Audit Reason</label>
            <textarea
              required
              rows={3}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g. No matching credit found in bank statement as of EOD"
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setRejectTarget(null)}
              className="px-4 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-xs font-medium rounded-md bg-red-700 text-white"
            >
              Confirm Action
            </button>
          </div>
        </form>
      </Modal>

      {/* CSV Statement Import Modal */}
      <Modal
        open={csvOpen}
        onClose={() => setCsvOpen(false)}
        title="Import Bank Statement CSV"
        subtitle="Explicitly select the receiving bank account and map statement columns. Only CREDIT rows are processed; duplicates are quarantined."
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleImportCsv} className="space-y-4">
          <div>
            <label className="block text-xs font-medium mb-1">Receiving Bank Account</label>
            <select
              required
              value={csvAccountId}
              onChange={(e) => setCsvAccountId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            >
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.accountCode} — {a.bankName} ({a.accountNumberMasked}) · {a.upiId}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Upload CSV File</label>
              <input
                type="file"
                accept=".csv,text/csv"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleCsvFileUpload(f);
                }}
                className="w-full text-xs text-slate-600 dark:text-slate-300"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Source File Label</label>
              <input
                type="text"
                required
                value={csvFilename}
                onChange={(e) => setCsvFilename(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">
              CSV Content (Paste or edit after upload)
            </label>
            <textarea
              required
              rows={5}
              value={csvContent}
              onChange={(e) => {
                setCsvContent(e.target.value);
                const first = e.target.value.split(/\r?\n/)[0] || '';
                setCsvHeaders(first.split(',').map((c) => c.trim().replace(/^"|"$/g, '')).filter(Boolean));
              }}
              placeholder={'Date,Type,Amount,UTR,Narration\n2026-11-19,CR,5000.00,432198765432,UPI/CR/FXPAY-2026-XXXXXX'}
              className="w-full px-3 py-2 text-xs font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {(
              [
                ['dateColumn', 'Date Col'],
                ['directionColumn', 'CR/DR Col'],
                ['amountColumn', 'Amount Col'],
                ['utrColumn', 'UTR Col'],
                ['descriptionColumn', 'Narration Col'],
              ] as const
            ).map(([field, label]) => (
              <div key={field}>
                <label className="block text-[11px] font-medium mb-1">{label}</label>
                {csvHeaders.length > 0 ? (
                  <select
                    value={mapping[field]}
                    onChange={(e) => setMapping({ ...mapping, [field]: e.target.value })}
                    className="w-full px-2 py-1.5 text-xs rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                  >
                    {csvHeaders.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    value={mapping[field]}
                    onChange={(e) => setMapping({ ...mapping, [field]: e.target.value })}
                    className="w-full px-2 py-1.5 text-xs rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                  />
                )}
              </div>
            ))}
          </div>

          <div className="flex items-start gap-2 text-[11px] text-slate-500 dark:text-slate-400">
            <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            <span>
              Imported statement records are sensitive financial data restricted strictly to Finance HQ & Super Admin. Debits are ignored; credits never auto-verify until confirmed.
            </span>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setCsvOpen(false)}
              className="px-4 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
            >
              {submitting ? 'Importing & Classifying...' : 'Run Reconciliation Import'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Manual Bind Modal for Ambiguous/Unmatched Bank Credit */}
      <Modal
        open={Boolean(bindMatch)}
        onClose={() => setBindMatch(null)}
        title="Bind Bank Credit to Payment Attempt"
        subtitle="Explicitly assign an ambiguous or unmatched bank credit to a verified payment obligation."
      >
        <div className="space-y-4">
          <div className="text-xs text-slate-600 dark:text-slate-300">
            Bank Credit:{' '}
            <span className="font-mono font-semibold">
              {formatInr(bindMatch?.bankTransaction.amountPaise)}
            </span>{' '}
            · UTR:{' '}
            <span className="font-mono">
              {bindMatch?.bankTransaction.bankReferenceUtr || 'Missing'}
            </span>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Target Payment Attempt</label>
            <select
              value={bindAttemptId}
              onChange={(e) => setBindAttemptId(e.target.value)}
              className="w-full px-3 py-2 text-xs font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            >
              {queue.map((q) => (
                <option key={q.attempt.id} value={q.attempt.id}>
                  {q.attempt.paymentRef} — {q.customer.name} ({formatInr(q.attempt.expectedAmountPaise)})
                </option>
              ))}
            </select>
          </div>
          {!bindMatch?.bankTransaction.bankReferenceUtr && (
            <div>
              <label className="block text-xs font-medium mb-1">Verified Bank UTR</label>
              <input
                type="text"
                required
                value={bindUtrOverride}
                onChange={(e) => setBindUtrOverride(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
          )}
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setBindMatch(null)}
              className="px-4 py-2 text-xs rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={submitting || !bindAttemptId}
              onClick={() =>
                bindMatch && handleConfirmMatch(bindMatch, bindAttemptId, bindUtrOverride)
              }
              className="px-4 py-2 text-xs font-medium rounded-md bg-emerald-700 text-white"
            >
              Confirm & Verify Payment
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
