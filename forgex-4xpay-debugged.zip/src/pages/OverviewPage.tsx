import React, { useEffect, useState, useCallback } from 'react';
import { ArrowRight, RefreshCw } from 'lucide-react';
import { apiRequest } from '../lib/api.ts';
import { formatInr, formatUtcDateTime } from '../lib/format.ts';
import { NavSection, SkeletonRows, StatusText } from '../components/Shell.tsx';

interface OverviewResponse {
  metrics: {
    totalVerifiedCollectionsPaise: number;
    totalExpectedPaise: number;
    totalReportedUnverifiedPaise: number;
    outstandingBalancePaise: number;
    outstandingInvoicesCount: number;
    paymentsAwaitingVerificationCount: number;
    activeDisputesCount: number;
    reconciliationExceptionsCount: number;
    connectedApplicationsCount: number;
    apiTotalRequests: number;
    apiFailedRequests: number;
  };
  activeReceivingAccount: {
    accountCode: string;
    bankName: string;
    accountNumberMasked: string;
    upiId: string;
    manualCheckAttested: boolean;
  } | null;
  recentTransactions: Array<{
    id: string;
    paymentRef: string;
    customerRef: string;
    customerName: string;
    invoiceRef: string;
    category: string;
    expectedAmountPaise: number;
    verifiedAmountPaise: number | null;
    status: string;
    verifiedUtr: string | null;
    customerReportedUtr: string | null;
    createdAt: string;
  }>;
}

export function OverviewPage({ onNavigate }: { onNavigate: (s: NavSection) => void }) {
  const [data, setData] = useState<OverviewResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<OverviewResponse>('/overview');
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load dashboard metrics.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (loading && !data) {
    return (
      <div className="space-y-6">
        <div className="h-7 w-64 bg-slate-200 dark:bg-slate-800 rounded animate-pulse" />
        <SkeletonRows rows={6} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="border border-red-200 dark:border-red-900/60 bg-white dark:bg-slate-900 rounded-lg p-6">
        <h2 className="text-base font-semibold text-red-700 dark:text-red-400">
          Failed to Load Overview
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{error}</p>
        <button
          type="button"
          onClick={load}
          className="mt-4 px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900"
        >
          Retry
        </button>
      </div>
    );
  }

  const m = data!.metrics;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Financial Operations Overview
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Live database-backed collections separating expected dues, customer-reported claims, and verified bank credits.
          </p>
        </div>
        <button
          type="button"
          onClick={load}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh</span>
        </button>
      </div>

      {/* Receiving Account Setup Banner (honest empty state when unconfigured) */}
      {!data!.activeReceivingAccount ? (
        <div className="border border-amber-300 dark:border-amber-800/80 bg-amber-50/70 dark:bg-amber-950/20 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="max-w-2xl">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Receiving UPI Account Not Configured
            </h2>
            <p className="mt-1 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
              No active receiving bank account is configured. ForgeX 4XPay never ships with fictional production bank details. Register and activate your authorised receiving UPI account before initiating customer payments.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('receiving-accounts')}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950 hover:opacity-90 transition-opacity whitespace-nowrap shrink-0"
          >
            <span>Configure Receiving Account</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg px-5 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600 dark:text-slate-400">
            <span className="font-semibold text-slate-900 dark:text-slate-100">
              Active Receiving UPI
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-900 dark:text-slate-100">
              {data!.activeReceivingAccount.upiId}
            </span>
            <span aria-hidden="true">·</span>
            <span>{data!.activeReceivingAccount.bankName}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">{data!.activeReceivingAccount.accountNumberMasked}</span>
            <span aria-hidden="true">·</span>
            <span
              className={
                data!.activeReceivingAccount.manualCheckAttested
                  ? 'text-emerald-700 dark:text-emerald-400 font-medium'
                  : 'text-amber-700 dark:text-amber-400 font-medium'
              }
            >
              {data!.activeReceivingAccount.manualCheckAttested
                ? 'Manual Check Attested'
                : 'Manual Check Pending'}
            </span>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('receiving-accounts')}
            className="text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white underline underline-offset-2 whitespace-nowrap shrink-0"
          >
            Manage Accounts
          </button>
        </div>
      )}

      {/* Primary Financial Separation Grid: Verified vs Expected vs Reported vs Outstanding */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg divide-y sm:divide-y-0 sm:divide-x divide-slate-200 dark:divide-slate-800">
        <div className="p-5">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Total Verified Collections
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
            {formatInr(m.totalVerifiedCollectionsPaise)}
          </div>
          <div className="mt-1.5 text-xs text-slate-500 dark:text-slate-400">
            Ledger-backed confirmed credits
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Outstanding Balance Due
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {formatInr(m.outstandingBalancePaise)}
          </div>
          <div className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            {m.outstandingInvoicesCount} open invoices · {formatInr(m.totalExpectedPaise)} billed
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Payments Awaiting Verification
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-amber-700 dark:text-amber-400">
            {m.paymentsAwaitingVerificationCount}
          </div>
          <div className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            {formatInr(m.totalReportedUnverifiedPaise)} customer-reported (unverified)
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Exceptions & Disputes
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {m.activeDisputesCount + m.reconciliationExceptionsCount}
          </div>
          <div className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            {m.activeDisputesCount} disputes · {m.reconciliationExceptionsCount} recon exceptions
          </div>
        </div>
      </div>

      {/* Secondary Ecosystem Operational Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          type="button"
          onClick={() => onNavigate('pending-verification')}
          className="text-left border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg p-5 hover:border-slate-400 dark:hover:border-slate-600 transition-colors"
        >
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Verification Queue
            </span>
            <ArrowRight className="w-4 h-4 text-slate-400" />
          </div>
          <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400">
            Review reported transfers against your banking app or import CSV bank statements.
          </p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('connected-apps')}
          className="text-left border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg p-5 hover:border-slate-400 dark:hover:border-slate-600 transition-colors"
        >
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Connected ForgeX Apps
            </span>
            <span className="text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300">
              {m.connectedApplicationsCount} active
            </span>
          </div>
          <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400 font-mono tabular-nums">
            {m.apiTotalRequests} API requests · {m.apiFailedRequests} failed auth/scope attempts
          </p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('client-portal')}
          className="text-left border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg p-5 hover:border-slate-400 dark:hover:border-slate-600 transition-colors"
        >
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Client Payment Portal
            </span>
            <ArrowRight className="w-4 h-4 text-slate-400" />
          </div>
          <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400">
            Initiate unique Payment IDs, generate UPI QR codes, report transfers, and download receipts.
          </p>
        </button>
      </div>

      {/* Recent Transactions Table */}
      <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Recent Payment Attempts
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('transactions')}
            className="text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 whitespace-nowrap"
          >
            View all transactions
          </button>
        </div>

        {data!.recentTransactions.length === 0 ? (
          <div className="px-5 py-10 text-center">
            <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
              No payment attempts recorded yet
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Configure a receiving UPI account, register a customer & project, then initiate a payment attempt.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-950/40">
                  <th className="py-2.5 px-4 font-medium">Payment ID</th>
                  <th className="py-2.5 px-4 font-medium">Customer · Invoice</th>
                  <th className="py-2.5 px-4 font-medium">Category</th>
                  <th className="py-2.5 px-4 font-medium text-right">Expected</th>
                  <th className="py-2.5 px-4 font-medium">Bank UTR</th>
                  <th className="py-2.5 px-4 font-medium">Status</th>
                  <th className="py-2.5 px-4 font-medium text-right">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {data!.recentTransactions.map((tx) => (
                  <tr
                    key={tx.id}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-4 font-mono font-medium text-slate-900 dark:text-slate-100 whitespace-nowrap">
                      {tx.paymentRef}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900 dark:text-slate-100">
                        {tx.customerName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {tx.customerRef} · {tx.invoiceRef}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{tx.category}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-slate-900 dark:text-slate-100">
                      {formatInr(tx.expectedAmountPaise)}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-300">
                      {tx.verifiedUtr || tx.customerReportedUtr || '—'}
                    </td>
                    <td className="py-3 px-4">
                      <StatusText status={tx.status} />
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      {formatUtcDateTime(tx.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
