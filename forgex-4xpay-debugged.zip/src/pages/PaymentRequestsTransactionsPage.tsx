import React, { useEffect, useState, useCallback } from 'react';
import { Plus, QrCode, Copy, Check, Download, ExternalLink, Search, SlidersHorizontal } from 'lucide-react';
import { apiRequest, createIdempotencyKey } from '../lib/api.ts';
import { formatInr, formatUtcDateTime, rupeesInputToPaise } from '../lib/format.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { EmptyState, Modal, SkeletonRows, StatusText } from '../components/Shell.tsx';
import { UpiQrGeneratorModal, UpiQrPreset } from '../components/UpiQrGenerator.tsx';

export interface CheckoutInfo {
  attemptId: string;
  paymentRef: string;
  expectedAmountPaise: number;
  currency: string;
  receivingUpiId: string;
  payeeName: string;
  upiUri: string;
  qrDataUrl: string;
  expiresAt: string;
  notice: string;
}

export function UpiCheckoutModal({
  checkout,
  onClose,
  onReported,
}: {
  checkout: CheckoutInfo | null;
  onClose: () => void;
  onReported: () => void;
}) {
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showReportForm, setShowReportForm] = useState(false);
  const [utr, setUtr] = useState('');
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [resultMsg, setResultMsg] = useState<string | null>(null);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  if (!checkout) return null;

  const copyUpi = async () => {
    await navigator.clipboard.writeText(checkout.receivingUpiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 1800);
  };

  const copyDeepLink = async () => {
    await navigator.clipboard.writeText(checkout.upiUri);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 1800);
  };

  const downloadQr = () => {
    const a = document.createElement('a');
    a.href = checkout.qrDataUrl;
    a.download = `${checkout.paymentRef}-UPI-QR.png`;
    a.click();
  };

  const submitReport = async (outcome: 'PAID' | 'FAILED') => {
    setSubmitting(true);
    setErrMsg(null);
    setResultMsg(null);
    try {
      const res = await apiRequest<{ message: string }>(
        `/payments/${checkout.paymentRef}/report`,
        {
          method: 'POST',
          body: {
            outcome,
            utrReference: utr.trim(),
            reportedAmountPaise: checkout.expectedAmountPaise,
            note: note.trim(),
          },
        }
      );
      setResultMsg(res.message);
      setShowReportForm(false);
      onReported();
    } catch (err) {
      setErrMsg(err instanceof Error ? err.message : 'Unable to submit payment report.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      open={Boolean(checkout)}
      onClose={onClose}
      title={`UPI Payment Checkout — ${checkout.paymentRef}`}
      subtitle="Actual funds move through your installed UPI app and banking network. Finance verifies credit before issuing a receipt."
      maxWidth="max-w-2xl"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* QR Column */}
        <div className="flex flex-col items-center justify-center border border-slate-200 dark:border-slate-800 rounded-lg p-5 bg-slate-50/70 dark:bg-slate-950/60">
          <div className="text-xs text-slate-500 dark:text-slate-400">Expected Amount</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {formatInr(checkout.expectedAmountPaise)}
          </div>
          <div className="mt-4 bg-white p-3 rounded-lg border border-slate-200">
            <img
              src={checkout.qrDataUrl}
              alt={`UPI QR code for ${checkout.paymentRef}`}
              className="w-52 h-52 object-contain"
            />
          </div>
          <div className="mt-3 text-[11px] font-mono text-slate-500 dark:text-slate-400 text-center">
            Valid window until {formatUtcDateTime(checkout.expiresAt)}
          </div>
          <button
            type="button"
            onClick={downloadQr}
            className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download QR PNG</span>
          </button>
        </div>

        {/* Instructions & Actions Column */}
        <div className="space-y-4">
          <div className="space-y-2 text-xs">
            <div>
              <div className="text-slate-500 dark:text-slate-400">Unique Payment ID</div>
              <div className="font-mono font-semibold text-sm text-slate-900 dark:text-slate-100">
                {checkout.paymentRef}
              </div>
            </div>
            <div>
              <div className="text-slate-500 dark:text-slate-400">Payee Name</div>
              <div className="font-medium text-slate-900 dark:text-slate-100">
                {checkout.payeeName}
              </div>
            </div>
            <div>
              <div className="text-slate-500 dark:text-slate-400">Receiving UPI ID</div>
              <div className="mt-0.5 flex items-center gap-2">
                <span className="font-mono text-slate-900 dark:text-slate-100">
                  {checkout.receivingUpiId}
                </span>
                <button
                  type="button"
                  onClick={copyUpi}
                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  {copiedUpi ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedUpi ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <a
                href={checkout.upiUri}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950 hover:opacity-90"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Pay via Installed UPI App</span>
              </a>
              <button
                type="button"
                onClick={copyDeepLink}
                className="inline-flex items-center gap-1 px-3 py-2.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 shrink-0"
                title="Copy upi://pay deep link"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied' : 'Copy URI'}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              On desktop or if no UPI app opens automatically, scan the QR code using PhonePe, Google Pay, or BHIM, or copy the UPI ID above. 4XPay never asks for your UPI PIN.
            </p>
          </div>

          {resultMsg && (
            <div className="border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/30 rounded-md p-3 text-xs text-emerald-800 dark:text-emerald-300">
              {resultMsg}
            </div>
          )}
          {errMsg && (
            <div className="border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/30 rounded-md p-3 text-xs text-red-700 dark:text-red-300">
              {errMsg}
            </div>
          )}

          {!resultMsg && !showReportForm && (
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => setShowReportForm(true)}
                className="w-full px-4 py-2 text-xs font-medium rounded-md border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Report Payment Already Made
              </button>
              <button
                type="button"
                onClick={() => submitReport('FAILED')}
                disabled={submitting}
                className="w-full px-4 py-2 text-xs font-medium rounded-md text-slate-600 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400"
              >
                Report UPI Transfer Failed
              </button>
            </div>
          )}

          {showReportForm && (
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div>
                <label className="block text-xs font-medium mb-1">
                  UPI Transaction Reference / UTR (12-digit preferred)
                </label>
                <input
                  type="text"
                  value={utr}
                  onChange={(e) => setUtr(e.target.value)}
                  placeholder="e.g. 432198765432"
                  className="w-full px-3 py-1.5 text-xs font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Optional Note</label>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Paid via PhonePe / GPay"
                  className="w-full px-3 py-1.5 text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowReportForm(false)}
                  className="px-3 py-1.5 text-xs rounded-md border border-slate-200 dark:border-slate-700"
                >
                  Back
                </button>
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => submitReport('PAID')}
                  className="px-3.5 py-1.5 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
                >
                  {submitting ? 'Submitting...' : 'Submit for Verification'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}

interface PaymentRequestItem {
  id: string;
  requestRef: string;
  invoiceRef: string;
  projectRef: string;
  projectName: string;
  customerRef: string;
  customerName: string;
  category: string;
  title: string;
  amountDuePaise: number;
  amountVerifiedPaise: number;
  remainingDuePaise: number;
  status: string;
  revisionNumber: number;
  createdAt: string;
}

interface ProjectOption {
  id: string;
  projectRef: string;
  name: string;
  customerName: string;
}

export function PaymentRequestsPage() {
  const { hasAnyRole, activeReceivingSummary } = useAuth();
  const canCreate = hasAnyRole('SUPER_ADMIN', 'ADMIN_HQ');
  const [requests, setRequests] = useState<PaymentRequestItem[]>([]);
  const [projects, setProjects] = useState<ProjectOption[]>([]);
  const [fallbackReceiving, setFallbackReceiving] = useState<{
    upiId: string;
    payeeName: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({
    projectId: '',
    category: 'ADVANCE' as 'ADVANCE' | 'MILESTONE' | 'FINAL',
    title: 'Project Advance Payment',
    amountRupees: '5000',
  });
  const [submitting, setSubmitting] = useState(false);
  const [checkout, setCheckout] = useState<CheckoutInfo | null>(null);
  const [qrUtilityPreset, setQrUtilityPreset] = useState<UpiQrPreset | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [reqRes, projRes, overviewRes] = await Promise.all([
        apiRequest<{ paymentRequests: PaymentRequestItem[] }>('/payment-requests'),
        apiRequest<{ projects: ProjectOption[] }>('/projects'),
        apiRequest<{
          activeReceivingAccount: { upiId: string; bankName: string } | null;
        }>('/overview').catch(() => null),
      ]);
      setRequests(reqRes.paymentRequests);
      setProjects(projRes.projects);
      if (overviewRes?.activeReceivingAccount?.upiId) {
        setFallbackReceiving({
          upiId: overviewRes.activeReceivingAccount.upiId,
          payeeName: activeReceivingSummary?.displayPayeeName || 'ForgeX 4XPay',
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load payment requests.');
    } finally {
      setLoading(false);
    }
  }, [activeReceivingSummary?.displayPayeeName]);

  useEffect(() => {
    load();
  }, [load]);

  const activeVpa = activeReceivingSummary?.upiId || fallbackReceiving?.upiId || '';
  const activePayeeName =
    activeReceivingSummary?.displayPayeeName || fallbackReceiving?.payeeName || 'ForgeX 4XPay';

  const openUtilityForRequest = (reqItem: PaymentRequestItem) => {
    const duePaise =
      reqItem.remainingDuePaise > 0 ? reqItem.remainingDuePaise : reqItem.amountDuePaise;
    setQrUtilityPreset({
      requestId: reqItem.id,
      requestRef: reqItem.requestRef,
      customerName: reqItem.customerName,
      projectName: reqItem.projectName,
      vpa: activeVpa,
      payeeName: activePayeeName,
      amountRupees: (duePaise / 100).toFixed(2),
      transactionId: reqItem.requestRef,
      transactionNote: `${reqItem.requestRef} ${reqItem.title}`.slice(0, 80),
    });
  };

  const openCustomQrUtility = () => {
    const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    setQrUtilityPreset({
      vpa: activeVpa,
      payeeName: activePayeeName,
      amountRupees: '1000.00',
      transactionId: `FXUPI-${stamp}-001`,
      transactionNote: 'ForgeX 4XPay UPI Collection',
    });
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const amountDuePaise = rupeesInputToPaise(form.amountRupees);
      const res = await apiRequest<{ paymentRequest: { requestRef: string } }>('/payment-requests', {
        method: 'POST',
        body: {
          projectId: form.projectId,
          category: form.category,
          title: form.title,
          amountDuePaise,
        },
      });
      setNotice(`Payment Request ${res.paymentRequest.requestRef} created.`);
      setCreateOpen(false);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create payment request.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleInitiateUpi = async (reqItem: PaymentRequestItem) => {
    setError(null);
    try {
      const res = await apiRequest<{
        attempt: { id: string };
        checkout: Omit<CheckoutInfo, 'attemptId'>;
      }>(`/payment-requests/${reqItem.id}/attempts`, {
        method: 'POST',
        headers: { 'Idempotency-Key': createIdempotencyKey('req') },
        body: {},
      });
      setCheckout({ ...res.checkout, attemptId: res.attempt.id });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to generate UPI payment attempt.');
    }
  };

  const handleCancel = async (reqItem: PaymentRequestItem) => {
    setError(null);
    try {
      await apiRequest(`/payment-requests/${reqItem.id}`, {
        method: 'PATCH',
        body: { action: 'CANCEL', reason: 'Cancelled by operator prior to verification' },
      });
      setNotice(`Payment Request ${reqItem.requestRef} cancelled with audit record.`);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to cancel request.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Payment Requests
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Authorised instalment requests (FXREQ-*). Every deliberate Pay Now action mints a unique Payment ID (FXPAY-*).
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={openCustomQrUtility}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>UPI QR Utility</span>
          </button>
          {canCreate && (
            <button
              type="button"
              disabled={projects.length === 0}
              onClick={() => {
                setForm((f) => ({ ...f, projectId: projects[0]?.id || '' }));
                setCreateOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950 disabled:opacity-40 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Payment Request</span>
            </button>
          )}
        </div>
      </div>

      {notice && (
        <div className="border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/20 rounded-lg px-4 py-3 text-xs text-emerald-800 dark:text-emerald-300">
          {notice}
        </div>
      )}
      {error && (
        <div className="border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/20 rounded-lg px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {loading ? (
        <SkeletonRows rows={5} />
      ) : requests.length === 0 ? (
        <EmptyState
          title="No payment requests yet"
          description="Create a customer and project schedule first, or issue a standalone payment request for an existing project."
        />
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-950/40">
                  <th className="py-2.5 px-4 font-medium">Request ID</th>
                  <th className="py-2.5 px-4 font-medium">Customer · Project</th>
                  <th className="py-2.5 px-4 font-medium">Instalment</th>
                  <th className="py-2.5 px-4 font-medium text-right">Due</th>
                  <th className="py-2.5 px-4 font-medium text-right">Verified</th>
                  <th className="py-2.5 px-4 font-medium">Status</th>
                  <th className="py-2.5 px-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {requests.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-mono font-semibold text-slate-900 dark:text-slate-100 whitespace-nowrap">
                      {r.requestRef}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900 dark:text-slate-100">
                        {r.customerName} · {r.projectName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {r.invoiceRef} · Rev {r.revisionNumber}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-900 dark:text-slate-100">{r.title}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">{r.category}</div>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right">
                      {formatInr(r.amountDuePaise)}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-emerald-700 dark:text-emerald-400">
                      {formatInr(r.amountVerifiedPaise)}
                    </td>
                    <td className="py-3 px-4">
                      <StatusText status={r.status} />
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                      {r.status !== 'PAID' && r.status !== 'CANCELLED' && (
                        <>
                          <button
                            type="button"
                            onClick={() => openUtilityForRequest(r)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                            title="Preview or customize UPI deep-link QR parameters"
                          >
                            <SlidersHorizontal className="w-3 h-3" />
                            <span>Quick QR</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleInitiateUpi(r)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950 hover:opacity-90"
                          >
                            <QrCode className="w-3 h-3" />
                            <span>Generate UPI QR</span>
                          </button>
                          {canCreate && r.amountVerifiedPaise === 0 && (
                            <button
                              type="button"
                              onClick={() => handleCancel(r)}
                              className="px-2.5 py-1 text-xs font-medium rounded border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-red-600"
                            >
                              Cancel
                            </button>
                          )}
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Create Payment Request"
        subtitle="Creates an authoritative FXREQ-* obligation backed by an invoice record."
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium mb-1">Project</label>
            <select
              required
              value={form.projectId}
              onChange={(e) => setForm({ ...form, projectId: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.projectRef} — {p.name} ({p.customerName})
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Category</label>
              <select
                value={form.category}
                onChange={(e) =>
                  setForm({ ...form, category: e.target.value as 'ADVANCE' | 'MILESTONE' | 'FINAL' })
                }
                className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              >
                <option value="ADVANCE">Advance</option>
                <option value="MILESTONE">Milestone</option>
                <option value="FINAL">Final</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Amount Due (INR)</label>
              <input
                type="text"
                required
                value={form.amountRupees}
                onChange={(e) => setForm({ ...form, amountRupees: e.target.value })}
                className="w-full px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Title / Description</label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="px-4 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
            >
              {submitting ? 'Creating...' : 'Create Request'}
            </button>
          </div>
        </form>
      </Modal>

      <UpiCheckoutModal
        checkout={checkout}
        onClose={() => setCheckout(null)}
        onReported={load}
      />

      <UpiQrGeneratorModal
        open={Boolean(qrUtilityPreset)}
        onClose={() => setQrUtilityPreset(null)}
        preset={qrUtilityPreset}
        onMintOfficialAttempt={(requestId) => {
          const matched = requests.find((item) => item.id === requestId);
          setQrUtilityPreset(null);
          if (matched) {
            void handleInitiateUpi(matched);
          }
        }}
      />
    </div>
  );
}

interface TransactionRow {
  id: string;
  paymentRef: string;
  requestRef: string;
  invoiceRef: string;
  projectRef: string;
  projectName: string;
  customerRef: string;
  customerName: string;
  category: string;
  receivingUpiSnapshot: string;
  expectedAmountPaise: number;
  reportedAmountPaise: number | null;
  verifiedAmountPaise: number | null;
  status: string;
  customerReportedUtr: string | null;
  verifiedUtr: string | null;
  createdAt: string;
  verifiedAt: string | null;
}

export function TransactionsPage() {
  const [rows, setRows] = useState<TransactionRow[]>([]);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<{ transactions: TransactionRow[] }>(
        `/transactions?status=${encodeURIComponent(statusFilter)}`
      );
      setRows(res.transactions);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load transactions.');
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = rows.filter((r) => {
    if (!query.trim()) return true;
    const q = query.trim().toLowerCase();
    return (
      r.paymentRef.toLowerCase().includes(q) ||
      r.customerName.toLowerCase().includes(q) ||
      r.invoiceRef.toLowerCase().includes(q) ||
      (r.verifiedUtr || '').toLowerCase().includes(q) ||
      (r.customerReportedUtr || '').toLowerCase().includes(q)
    );
  });

  const filterOptions = [
    'ALL',
    'AWAITING_PAYMENT',
    'VERIFICATION_PENDING',
    'REVIEW_REQUIRED',
    'VERIFIED',
    'DISPUTED',
    'FAILED_REPORTED',
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Transactions Ledger
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Complete immutable history of payment attempts with independent ForgeX Payment IDs and bank UTR references.
        </p>
      </div>

      {/* Filters & Live Search */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          {filterOptions.map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              {st === 'ALL' ? 'All' : st.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search Payment ID, UTR, customer..."
            className="w-full pl-8 pr-3 py-2 text-xs rounded-md border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
          />
        </div>
      </div>

      {error && (
        <div className="border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/20 rounded-lg px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {loading ? (
        <SkeletonRows rows={6} />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No matching transactions"
          description="No payment attempts match the selected status filter and search query."
        />
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-950/40">
                  <th className="py-2.5 px-4 font-medium">Payment ID · Request</th>
                  <th className="py-2.5 px-4 font-medium">Customer · Project</th>
                  <th className="py-2.5 px-4 font-medium">Receiving UPI</th>
                  <th className="py-2.5 px-4 font-medium text-right">Expected</th>
                  <th className="py-2.5 px-4 font-medium text-right">Verified</th>
                  <th className="py-2.5 px-4 font-medium">Bank UTR</th>
                  <th className="py-2.5 px-4 font-medium">Status</th>
                  <th className="py-2.5 px-4 font-medium text-right">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {filtered.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                        {tx.paymentRef}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {tx.requestRef} · {tx.category}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900 dark:text-slate-100">
                        {tx.customerName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {tx.projectName} · {tx.invoiceRef}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-300">
                      {tx.receivingUpiSnapshot}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right">
                      {formatInr(tx.expectedAmountPaise)}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-emerald-700 dark:text-emerald-400">
                      {tx.verifiedAmountPaise ? formatInr(tx.verifiedAmountPaise) : '—'}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300">
                      {tx.verifiedUtr ? (
                        <span className="text-emerald-700 dark:text-emerald-400">{tx.verifiedUtr}</span>
                      ) : tx.customerReportedUtr ? (
                        <span className="text-amber-700 dark:text-amber-400">
                          {tx.customerReportedUtr} (claimed)
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <StatusText status={tx.status} />
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      {formatUtcDateTime(tx.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
