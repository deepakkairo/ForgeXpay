import React, { useState } from 'react';
import {
  LayoutDashboard,
  ArrowLeftRight,
  FileSpreadsheet,
  ShieldCheck,
  Landmark,
  Users,
  FileText,
  Receipt,
  AlertTriangle,
  Blocks,
  KeyRound,
  ScrollText,
  Lock,
  Activity,
  Briefcase,
  Smartphone,
  Bell,
  Sun,
  Moon,
  LogOut,
  Menu,
  X,
} from 'lucide-react';
import { useAuth, RoleCode } from '../context/AuthContext.tsx';
import { useTheme } from '../context/ThemeContext.tsx';
import { apiRequest } from '../lib/api.ts';
import { formatUtcDateTime, statusColorClass, humanizeStatus } from '../lib/format.ts';

export type NavSection =
  | 'overview'
  | 'transactions'
  | 'payment-requests'
  | 'pending-verification'
  | 'receiving-accounts'
  | 'customers'
  | 'invoices'
  | 'receipts'
  | 'disputes'
  | 'connected-apps'
  | 'api-credentials'
  | 'audit-logs'
  | 'security-settings'
  | 'system-health'
  | 'client-portal'
  | 'employee-hq';

interface NavItem {
  id: NavSection;
  label: string;
  breadcrumb: string;
  icon: React.ComponentType<{ className?: string }>;
  group: 'Operations' | 'Configuration' | 'Governance' | 'Ecosystem Portals';
  roles: RoleCode[];
}

export const NAV_ITEMS: NavItem[] = [
  {
    id: 'overview',
    label: 'Overview',
    breadcrumb: 'Dashboard / Overview',
    icon: LayoutDashboard,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'transactions',
    label: 'Transactions',
    breadcrumb: 'Operations / Transactions',
    icon: ArrowLeftRight,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'payment-requests',
    label: 'Payment Requests',
    breadcrumb: 'Operations / Payment Requests',
    icon: FileSpreadsheet,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'pending-verification',
    label: 'Pending Verification',
    breadcrumb: 'Finance HQ / Pending Verification & Reconciliation',
    icon: ShieldCheck,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN'],
  },
  {
    id: 'customers',
    label: 'Customers',
    breadcrumb: 'Billing / Customers & Projects',
    icon: Users,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'invoices',
    label: 'Invoices',
    breadcrumb: 'Billing / Invoices',
    icon: FileText,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'receipts',
    label: 'Receipts',
    breadcrumb: 'Billing / Verified Receipts',
    icon: Receipt,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'disputes',
    label: 'Missing Payments',
    breadcrumb: 'Support / Missing Payments & Disputes',
    icon: AlertTriangle,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'receiving-accounts',
    label: 'Receiving Accounts',
    breadcrumb: 'Settings / Payment Configuration / Receiving Accounts',
    icon: Landmark,
    group: 'Configuration',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN'],
  },
  {
    id: 'connected-apps',
    label: 'Connected Apps',
    breadcrumb: 'Platform / Connected Applications',
    icon: Blocks,
    group: 'Configuration',
    roles: ['SUPER_ADMIN'],
  },
  {
    id: 'api-credentials',
    label: 'API Credentials',
    breadcrumb: 'Platform / API Credentials',
    icon: KeyRound,
    group: 'Configuration',
    roles: ['SUPER_ADMIN'],
  },
  {
    id: 'audit-logs',
    label: 'Audit Logs',
    breadcrumb: 'Governance / Audit Logs',
    icon: ScrollText,
    group: 'Governance',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN'],
  },
  {
    id: 'security-settings',
    label: 'Security Settings',
    breadcrumb: 'Governance / Security & Tax Settings',
    icon: Lock,
    group: 'Governance',
    roles: ['SUPER_ADMIN'],
  },
  {
    id: 'system-health',
    label: 'System Health',
    breadcrumb: 'Governance / System Health',
    icon: Activity,
    group: 'Governance',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN'],
  },
  {
    id: 'client-portal',
    label: 'Client App Portal',
    breadcrumb: 'ForgeX Ecosystem / Client Payment Portal',
    icon: Smartphone,
    group: 'Ecosystem Portals',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ', 'CLIENT'],
  },
  {
    id: 'employee-hq',
    label: 'Employee HQ',
    breadcrumb: 'ForgeX Ecosystem / Employee HQ (Restricted)',
    icon: Briefcase,
    group: 'Ecosystem Portals',
    roles: ['SUPER_ADMIN', 'ADMIN_HQ', 'EMPLOYEE'],
  },
];

interface NotificationItem {
  id: string;
  eventType: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export function StatusText({ status }: { status: string }) {
  return (
    <span className={`font-medium text-xs tracking-tight whitespace-nowrap ${statusColorClass(status)}`}>
      {humanizeStatus(status)}
    </span>
  );
}

export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg p-10 text-center">
      <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">{title}</h3>
      <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 max-w-lg mx-auto leading-relaxed">
        {description}
      </p>
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  );
}

export function SkeletonRows({ rows = 5 }: { rows?: number }) {
  return (
    <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg divide-y divide-slate-200 dark:divide-slate-800">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="px-4 py-3.5 flex items-center justify-between gap-4 animate-pulse">
          <div className="h-3.5 w-36 bg-slate-200 dark:bg-slate-800 rounded" />
          <div className="h-3.5 w-48 bg-slate-100 dark:bg-slate-800/70 rounded" />
          <div className="h-3.5 w-24 bg-slate-200 dark:bg-slate-800 rounded" />
        </div>
      ))}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  maxWidth = 'max-w-xl',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  maxWidth?: string;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-[2px] p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div
        className={`w-full ${maxWidth} bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg shadow-xl my-8`}
      >
        <div className="flex items-start justify-between gap-4 px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">{title}</h2>
            {subtitle && (
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-6 max-h-[78vh] overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

export function Shell({
  active,
  onNavigate,
  children,
}: {
  active: NavSection;
  onNavigate: (section: NavSection) => void;
  children: React.ReactNode;
}) {
  const { profile, unreadNotifications, logout, refreshProfile } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifList, setNotifList] = useState<NotificationItem[]>([]);
  const [notifLoading, setNotifLoading] = useState(false);

  const visibleItems = NAV_ITEMS.filter((item) =>
    profile ? item.roles.some((r) => profile.roles.includes(r)) : false
  );
  const currentItem = visibleItems.find((i) => i.id === active) || visibleItems[0];
  const groups: Array<NavItem['group']> = [
    'Operations',
    'Configuration',
    'Governance',
    'Ecosystem Portals',
  ];

  const openNotifications = async () => {
    setNotifOpen(true);
    setNotifLoading(true);
    try {
      const data = await apiRequest<{ notifications: NotificationItem[] }>('/notifications');
      setNotifList(data.notifications);
    } catch {
      // handled silently
    } finally {
      setNotifLoading(false);
    }
  };

  const markAllRead = async () => {
    await apiRequest('/notifications/read-all', { method: 'POST' });
    setNotifList((prev) => prev.map((n) => ({ ...n, isRead: true })));
    await refreshProfile();
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800">
      <div className="h-14 px-5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800 shrink-0">
        <button
          type="button"
          onClick={() => {
            onNavigate(visibleItems[0]?.id || 'overview');
            setMobileMenuOpen(false);
          }}
          className="text-base font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap"
        >
          ForgeX 4XPay
        </button>
        <button
          type="button"
          onClick={() => setMobileMenuOpen(false)}
          className="lg:hidden p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100"
          aria-label="Close navigation"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5" aria-label="Primary navigation">
        {groups.map((group) => {
          const items = visibleItems.filter((i) => i.group === group);
          if (items.length === 0) return null;
          return (
            <div key={group}>
              <div className="px-2.5 mb-1.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500 tracking-wide">
                {group}
              </div>
              <div className="space-y-0.5">
                {items.map((item) => {
                  const Icon = item.icon;
                  const isActive = item.id === active;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        onNavigate(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${
                        isActive
                          ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950'
                          : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-slate-100'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </nav>

      <div className="p-3 border-t border-slate-200 dark:border-slate-800 shrink-0">
        <div className="px-2 py-1.5">
          <div className="text-xs font-medium text-slate-900 dark:text-slate-100 truncate">
            {profile?.displayName}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
            {profile?.email}
          </div>
          <div className="mt-1 text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate">
            {profile?.roles.join(' · ')}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 sticky top-0 h-screen">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="w-64 h-full">{sidebarContent}</div>
          <div
            className="flex-1 bg-slate-950/50"
            onClick={() => setMobileMenuOpen(false)}
          />
        </div>
      )}

      {/* Main Column */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-14 sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur border-b border-slate-200 dark:border-slate-800 px-4 lg:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation"
              className="lg:hidden p-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="text-sm font-medium text-slate-600 dark:text-slate-300 truncate">
              {currentItem?.breadcrumb || 'ForgeX 4XPay'}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={openNotifications}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
              aria-label="Open notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifications > 0 && (
                <span className="font-mono tabular-nums font-semibold text-amber-700 dark:text-amber-400">
                  {unreadNotifications}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={toggleTheme}
              className="p-2 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
              aria-label="Toggle color theme"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={logout}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </header>

        <main className="flex-1 px-4 lg:px-8 py-6 max-w-[1400px] w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Notifications Modal */}
      <Modal
        open={notifOpen}
        onClose={() => setNotifOpen(false)}
        title="Internal Notifications"
        subtitle="Event-driven alerts across ForgeX 4XPay. Notification delivery never alters verified financial truth."
      >
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            {notifList.length} recent events
          </span>
          {notifList.some((n) => !n.isRead) && (
            <button
              type="button"
              onClick={markAllRead}
              className="text-xs font-medium text-slate-900 dark:text-slate-100 underline underline-offset-2"
            >
              Mark all read
            </button>
          )}
        </div>
        {notifLoading ? (
          <SkeletonRows rows={3} />
        ) : notifList.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400 py-6 text-center">
            No notifications recorded yet.
          </p>
        ) : (
          <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
            {notifList.map((n) => (
              <div
                key={n.id}
                className={`p-3.5 ${n.isRead ? 'opacity-70' : 'bg-slate-50/70 dark:bg-slate-800/30'}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                    {n.title}
                  </span>
                  <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                    {formatUtcDateTime(n.createdAt)}
                  </span>
                </div>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {n.message}
                </p>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
