import React, { useState, useEffect } from 'react';
import { ShieldCheck, Landmark, FileCheck2, Lock } from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { ThemeProvider, useTheme } from './context/ThemeContext.tsx';
import { Shell, NavSection, NAV_ITEMS } from './components/Shell.tsx';
import { OverviewPage } from './pages/OverviewPage.tsx';
import { ReceivingAccountsPage } from './pages/ReceivingAccountsPage.tsx';
import { CustomersProjectsPage } from './pages/CustomersProjectsPage.tsx';
import {
  PaymentRequestsPage,
  TransactionsPage,
} from './pages/PaymentRequestsTransactionsPage.tsx';
import { VerificationQueuePage } from './pages/VerificationQueuePage.tsx';
import {
  InvoicesPage,
  ReceiptsPage,
  DisputesPage,
} from './pages/InvoicesReceiptsDisputesPage.tsx';
import {
  ConnectedAppsAndApiPage,
  AuditLogsPage,
  SecuritySettingsPage,
  SystemHealthPage,
} from './pages/ApplicationsApiAuditPage.tsx';
import {
  ClientPortalPage,
  EmployeeHqPage,
} from './pages/ClientEmployeePortalsPage.tsx';

function LoginGate() {
  const { signInWithGoogle, authError } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [signingIn, setSigningIn] = useState(false);

  const handleSignIn = async () => {
    setSigningIn(true);
    try {
      await signInWithGoogle();
    } finally {
      setSigningIn(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <header className="h-16 px-6 lg:px-12 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-8 bg-white dark:bg-slate-900">
        <span className="text-lg font-bold tracking-tight whitespace-nowrap shrink-0">
          ForgeX 4XPay
        </span>
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-400">
          <span>UPI Collection</span>
          <span>Hybrid Verification</span>
          <span>Statement Reconciliation</span>
          <span>Central Ecosystem API</span>
        </nav>
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={toggleTheme}
            className="px-3 py-1.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap"
          >
            {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
          </button>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7 space-y-5">
            <p className="text-xs font-semibold tracking-wide text-slate-500 dark:text-slate-400">
              Private UPI Payment Collection & Verification Infrastructure
            </p>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-slate-100 leading-tight">
              Centralised UPI billing, verification, and ledger control for the ForgeX ecosystem.
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-xl">
              Generate unique Payment IDs and standards-compliant UPI QR codes using your own authorised receiving UPI address. Verify incoming transfers through Finance HQ manual checks or CSV bank statement reconciliation before issuing receipts.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-xs">
              <div className="flex items-start gap-2.5">
                <Landmark className="w-4 h-4 text-slate-700 dark:text-slate-300 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    Direct UPI Receiving Account
                  </div>
                  <div className="text-slate-500 dark:text-slate-400">
                    Zero commercial gateway SDKs; AES-256-GCM encrypted account storage.
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-slate-700 dark:text-slate-300 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    Backend-Controlled Verification
                  </div>
                  <div className="text-slate-500 dark:text-slate-400">
                    Duplicate UTR guards, dual-approval policy, and exactly-once ledger credits.
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <FileCheck2 className="w-4 h-4 text-slate-700 dark:text-slate-300 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    PDF Receipts & Invoices
                  </div>
                  <div className="text-slate-500 dark:text-slate-400">
                    Expiring signed download links issued strictly after credit verification.
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <Lock className="w-4 h-4 text-slate-700 dark:text-slate-300 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    Unified ForgeX RBAC & API Keys
                  </div>
                  <div className="text-slate-500 dark:text-slate-400">
                    Scoped access across Admin HQ, Finance HQ, Employee HQ, and Client App.
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg p-7 space-y-5">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  Sign in to ForgeX 4XPay
                </h2>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  Authenticate with your authorised Google account to access your assigned ForgeX workspace.
                </p>
              </div>

              {authError && (
                <div className="border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/30 rounded-md p-3 text-xs text-red-700 dark:text-red-300">
                  {authError}
                </div>
              )}

              <button
                type="button"
                disabled={signingIn}
                onClick={handleSignIn}
                className="w-full py-2.5 px-4 text-sm font-semibold rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950 hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                {signingIn ? 'Signing in...' : 'Continue with Google'}
              </button>

              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed pt-2 border-t border-slate-200 dark:border-slate-800">
                ForgeX 4XPay is a private internal payment collection and verification platform. It is not a licensed bank, UPI network participant, or payment aggregator. Actual funds transfer exclusively through the UPI banking network.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function AuthenticatedWorkspace() {
  const { profile, loading } = useAuth();
  const [section, setSection] = useState<NavSection>('overview');

  useEffect(() => {
    if (!profile) return;
    const allowed = NAV_ITEMS.filter((i) => i.roles.some((r) => profile.roles.includes(r)));
    if (allowed.length > 0 && !allowed.some((i) => i.id === section)) {
      setSection(allowed[0].id);
    }
  }, [profile, section]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
          Loading ForgeX 4XPay session...
        </div>
      </div>
    );
  }

  if (!profile) {
    return <LoginGate />;
  }

  const renderPage = () => {
    switch (section) {
      case 'overview':
        return <OverviewPage onNavigate={setSection} />;
      case 'transactions':
        return <TransactionsPage />;
      case 'payment-requests':
        return <PaymentRequestsPage />;
      case 'pending-verification':
        return <VerificationQueuePage />;
      case 'receiving-accounts':
        return <ReceivingAccountsPage />;
      case 'customers':
        return <CustomersProjectsPage />;
      case 'invoices':
        return <InvoicesPage />;
      case 'receipts':
        return <ReceiptsPage />;
      case 'disputes':
        return <DisputesPage />;
      case 'connected-apps':
        return <ConnectedAppsAndApiPage mode="apps" />;
      case 'api-credentials':
        return <ConnectedAppsAndApiPage mode="credentials" />;
      case 'audit-logs':
        return <AuditLogsPage />;
      case 'security-settings':
        return <SecuritySettingsPage />;
      case 'system-health':
        return <SystemHealthPage />;
      case 'client-portal':
        return <ClientPortalPage />;
      case 'employee-hq':
        return <EmployeeHqPage />;
      default:
        return <OverviewPage onNavigate={setSection} />;
    }
  };

  return (
    <Shell active={section} onNavigate={setSection}>
      {renderPage()}
    </Shell>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AuthenticatedWorkspace />
      </AuthProvider>
    </ThemeProvider>
  );
}
